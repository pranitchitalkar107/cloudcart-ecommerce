# CloudCart — Cloud-Based E-Commerce System (Frontend Demo)

A responsive e-commerce mini-project inspired by the clean dashboard style of the reference site.

## Run locally
1. Download and extract the project ZIP.
2. Open `index.html` in Chrome, Edge, or Firefox.
3. Search products, filter categories, add/remove cart items, and place a demo order.

## Features
- Responsive product catalog
- Search and category filters
- Shopping cart with quantity controls
- Checkout form and demo order confirmation
- Order history stored in the browser using localStorage
- INR currency display

## Important scope note
This is a frontend prototype. Cart and order data are saved only in the current browser. It does not include a Java server, cloud database, real login, or real payment processing.

## Suggested Java/cloud architecture for the full project
- Frontend: HTML, CSS, JavaScript
- Backend: Java + Spring Boot REST API
- Database: MySQL or PostgreSQL
- Cloud deployment: deploy the Java backend and database on a cloud provider; host the static frontend separately.
- Example API routes: `GET /api/products`, `POST /api/cart/items`, `POST /api/orders`, `GET /api/customers/{id}/orders`

GitHub Pages can host the static frontend, but it cannot run the Java backend itself. See GitHub Pages documentation: https://docs.github.com/en/pages/getting-started-with-github-pages
